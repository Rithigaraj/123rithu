import { Link, useNavigate } from "react-router-dom";
import { useStore } from "@/lib/store";
import { Car, LogOut, Shield, User } from "lucide-react";

export function Navbar() {
  const { isLoggedIn, isAdmin, userName, logout } = useStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 surface-glass border-b border-border">
      <div className="container mx-auto flex items-center justify-between h-16 px-6">
        <Link to="/" className="flex items-center gap-2">
          <Car className="h-6 w-6 text-primary" />
          <span className="font-display text-xl font-bold tracking-[-0.04em] text-foreground">
            VELOCE
          </span>
        </Link>

        <div className="flex items-center gap-4">
          {isLoggedIn ? (
            <>
              <span className="text-sm text-muted-foreground flex items-center gap-1.5">
                <User className="h-3.5 w-3.5" />
                {userName}
              </span>
              {isAdmin && (
                <Link
                  to="/admin"
                  className="text-sm text-primary flex items-center gap-1.5 hover:brightness-110 transition-all"
                >
                  <Shield className="h-3.5 w-3.5" />
                  Dashboard
                </Link>
              )}
              <button
                onClick={handleLogout}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"
              >
                <LogOut className="h-3.5 w-3.5" />
                Logout
              </button>
            </>
          ) : (
            <Link to="/login" className="btn-veloce text-sm py-2 px-4">
              Sign In
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
