import { motion } from "framer-motion";
import { Car } from "@/lib/car-data";
import { useStore } from "@/lib/store";
import { useNavigate } from "react-router-dom";
import { Fuel, Users, Zap } from "lucide-react";
import { toast } from "sonner";

interface CarCardProps {
  car: Car;
  index: number;
}

export function CarCard({ car, index }: CarCardProps) {
  const { isLoggedIn, userName, bookCar } = useStore();
  const navigate = useNavigate();

  const handleBook = () => {
    if (!isLoggedIn) {
      toast.error("Sign in required to confirm reservation.");
      navigate("/login");
      return;
    }
    bookCar(car.id, userName);
    toast.success(`Booking ${car.id} confirmed. Vehicle '${car.brand} ${car.name}' is now assigned to your profile.`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.08, ease: [0.2, 0.8, 0.2, 1] }}
      whileHover={{ scale: 1.02 }}
      className="card-veloce group"
    >
      <div className="relative overflow-hidden aspect-[16/10]">
        <img
          src={car.image}
          alt={`${car.brand} ${car.name}`}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute top-3 right-3">
          {car.status === "available" ? (
            <span className="badge-available">Available</span>
          ) : (
            <span className="badge-booked">Booked</span>
          )}
        </div>
      </div>

      <div className="p-5 space-y-4">
        <div>
          <p className="text-xs text-muted-foreground uppercase tracking-[0.15em] font-medium">
            {car.brand}
          </p>
          <h3 className="font-display text-lg font-bold tracking-[-0.02em] text-foreground">
            {car.name}
          </h3>
        </div>

        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Zap className="h-3.5 w-3.5 text-primary" />
            {car.hp} HP
          </span>
          <span className="flex items-center gap-1">
            <Users className="h-3.5 w-3.5 text-primary" />
            {car.seats}
          </span>
          <span className="flex items-center gap-1">
            <Fuel className="h-3.5 w-3.5 text-primary" />
            {car.fuel}
          </span>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-border">
          <span className="font-mono text-lg text-primary font-bold">
            ₹{car.price.toLocaleString("en-IN")}
            <span className="text-xs text-muted-foreground font-normal">/day</span>
          </span>

          {car.status === "available" ? (
            <button onClick={handleBook} className="btn-veloce text-sm py-2 px-4">
              Confirm Reservation
            </button>
          ) : (
            <span className="text-xs text-muted-foreground">Reserved</span>
          )}
        </div>
      </div>
    </motion.div>
  );
}
