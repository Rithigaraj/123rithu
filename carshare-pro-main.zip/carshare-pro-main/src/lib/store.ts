import { create } from "zustand";
import { Car, initialCars } from "./car-data";

interface AppState {
  cars: Car[];
  isLoggedIn: boolean;
  isAdmin: boolean;
  userName: string;
  bookCar: (carId: string, userName: string) => void;
  login: (email: string, password: string) => boolean;
  logout: () => void;
}

export const useStore = create<AppState>((set, get) => ({
  cars: initialCars,
  isLoggedIn: false,
  isAdmin: false,
  userName: "",

  bookCar: (carId, userName) => {
    set((state) => ({
      cars: state.cars.map((car) =>
        car.id === carId
          ? {
              ...car,
              status: "booked" as const,
              bookedBy: userName,
              bookingDate: new Date().toISOString().split("T")[0],
            }
          : car
      ),
    }));
  },

  login: (email, password) => {
    if (email === "admin@veloce.com" && password === "admin123") {
      set({ isLoggedIn: true, isAdmin: true, userName: "Admin" });
      return true;
    }
    if (email && password.length >= 4) {
      set({ isLoggedIn: true, isAdmin: false, userName: email.split("@")[0] });
      return true;
    }
    return false;
  },

  logout: () => {
    set({ isLoggedIn: false, isAdmin: false, userName: "" });
  },
}));
