import carPorsche from "@/assets/car-porsche.jpg";
import carTesla from "@/assets/car-tesla.jpg";
import carBmw from "@/assets/car-bmw.jpg";
import carMercedes from "@/assets/car-mercedes.jpg";
import carAudi from "@/assets/car-audi.jpg";
import carLambo from "@/assets/car-lambo.jpg";

export interface Car {
  id: string;
  name: string;
  brand: string;
  price: number; // per day in ₹
  image: string;
  seats: number;
  transmission: "Auto" | "Manual";
  fuel: "Petrol" | "Electric" | "Diesel";
  hp: number;
  status: "available" | "booked";
  bookedBy?: string;
  bookingDate?: string;
}

export const initialCars: Car[] = [
  {
    id: "VLC-001",
    name: "911 GT3",
    brand: "Porsche",
    price: 12500,
    image: carPorsche,
    seats: 2,
    transmission: "Auto",
    fuel: "Petrol",
    hp: 502,
    status: "available",
  },
  {
    id: "VLC-002",
    name: "Model 3 Performance",
    brand: "Tesla",
    price: 5200,
    image: carTesla,
    seats: 5,
    transmission: "Auto",
    fuel: "Electric",
    hp: 455,
    status: "available",
  },
  {
    id: "VLC-003",
    name: "M4 Competition",
    brand: "BMW",
    price: 8500,
    image: carBmw,
    seats: 4,
    transmission: "Auto",
    fuel: "Petrol",
    hp: 503,
    status: "available",
  },
  {
    id: "VLC-004",
    name: "AMG GT",
    brand: "Mercedes",
    price: 15000,
    image: carMercedes,
    seats: 2,
    transmission: "Auto",
    fuel: "Petrol",
    hp: 577,
    status: "available",
  },
  {
    id: "VLC-005",
    name: "RS7 Sportback",
    brand: "Audi",
    price: 9800,
    image: carAudi,
    seats: 5,
    transmission: "Auto",
    fuel: "Petrol",
    hp: 591,
    status: "available",
  },
  {
    id: "VLC-006",
    name: "Huracán EVO",
    brand: "Lamborghini",
    price: 22000,
    image: carLambo,
    seats: 2,
    transmission: "Auto",
    fuel: "Petrol",
    hp: 631,
    status: "available",
  },
];
