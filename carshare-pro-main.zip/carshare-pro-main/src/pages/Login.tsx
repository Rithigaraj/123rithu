import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useStore } from "@/lib/store";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";
import { Car, Lock, Mail } from "lucide-react";
import { toast } from "sonner";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useStore();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(email, password);
    if (success) {
      toast.success("Session initialized. Welcome back.");
      if (email === "admin@veloce.com") {
        navigate("/admin");
      } else {
        navigate("/");
      }
    } else {
      toast.error("Authentication failed. Verify credentials.");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="flex items-center justify-center min-h-screen px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
          className="card-veloce w-full max-w-md p-8"
        >
          <div className="flex items-center gap-3 mb-8">
            <Car className="h-8 w-8 text-primary" />
            <h1 className="font-display text-2xl font-bold tracking-[-0.04em] text-foreground">
              Sign In
            </h1>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="you@example.com"
                  className="w-full bg-muted border border-border rounded-[12px] py-3 pl-10 pr-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={4}
                  placeholder="••••••••"
                  className="w-full bg-muted border border-border rounded-[12px] py-3 pl-10 pr-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                />
              </div>
            </div>

            <button type="submit" className="btn-veloce w-full text-center">
              Initialize Session
            </button>
          </form>

          <div className="mt-6 p-4 rounded-[12px] bg-muted/50 border border-border">
            <p className="text-xs text-muted-foreground">
              <span className="text-primary font-bold">Admin access:</span> admin@veloce.com / admin123
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              <span className="text-accent font-bold">User access:</span> Any email / 4+ char password
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Login;
