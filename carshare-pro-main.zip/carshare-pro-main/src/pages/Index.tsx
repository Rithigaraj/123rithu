import { motion } from "framer-motion";
import { useStore } from "@/lib/store";
import { CarCard } from "@/components/CarCard";
import { Navbar } from "@/components/Navbar";

const Index = () => {
  const { cars } = useStore();
  const availableCount = cars.filter((c) => c.status === "available").length;
  const totalValue = cars
    .filter((c) => c.status === "available")
    .reduce((sum, c) => sum + c.price, 0);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-16 px-6">
        <div className="container mx-auto text-left max-w-5xl">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.2, 0.8, 0.2, 1] }}
            className="font-display text-5xl md:text-7xl font-bold tracking-[-0.04em] text-foreground leading-[1.05]"
            style={{ textWrap: "balance" } as React.CSSProperties}
          >
            Drive the machine.
            <br />
            <span className="text-primary">Skip the paperwork.</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15, ease: [0.2, 0.8, 0.2, 1] }}
            className="mt-6 text-lg text-muted-foreground max-w-xl"
          >
            Veloce is a high-performance car rental engine. Select. Reserve. Ignite.
          </motion.p>
        </div>
      </section>

      {/* Live Inventory Counter */}
      <section className="pb-12 px-6">
        <div className="container mx-auto max-w-5xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="surface-glass rounded-[20px] p-8 flex flex-col md:flex-row items-start md:items-center gap-8"
          >
            <div className="flex flex-col gap-1">
              <span className="text-xs font-bold tracking-[0.2em] text-muted-foreground uppercase">
                Live Inventory
              </span>
              <div className="text-6xl font-bold tabular-nums text-primary text-glow-primary animate-pulse-glow">
                {availableCount}
              </div>
              <span className="text-sm text-accent">Vehicles Ready to Ignite</span>
            </div>

            <div className="h-16 w-px bg-border hidden md:block" />

            <div className="flex flex-col gap-1">
              <span className="text-xs font-bold tracking-[0.2em] text-muted-foreground uppercase">
                Fleet Value
              </span>
              <div className="text-3xl font-mono font-bold text-foreground">
                ₹{totalValue.toLocaleString("en-IN")}
                <span className="text-sm text-muted-foreground font-normal">/day</span>
              </div>
              <span className="text-sm text-muted-foreground">Combined daily rate</span>
            </div>

            <div className="h-16 w-px bg-border hidden md:block" />

            <div className="flex flex-col gap-1">
              <span className="text-xs font-bold tracking-[0.2em] text-muted-foreground uppercase">
                Booked
              </span>
              <div className="text-3xl font-bold tabular-nums text-destructive">
                {cars.length - availableCount}
              </div>
              <span className="text-sm text-muted-foreground">Currently reserved</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Car Grid */}
      <section className="pb-20 px-6">
        <div className="container mx-auto max-w-5xl">
          <h2 className="font-display text-2xl font-bold tracking-[-0.02em] text-foreground mb-8">
            Available Fleet
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cars.map((car, i) => (
              <CarCard key={car.id} car={car} index={i} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
