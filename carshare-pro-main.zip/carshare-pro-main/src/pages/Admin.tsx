import { useStore } from "@/lib/store";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";
import { Navigate } from "react-router-dom";
import { Car, IndianRupee, ShieldCheck, TrendingUp } from "lucide-react";

const Admin = () => {
  const { cars, isLoggedIn, isAdmin } = useStore();

  if (!isLoggedIn || !isAdmin) {
    return <Navigate to="/login" replace />;
  }

  const booked = cars.filter((c) => c.status === "booked");
  const available = cars.filter((c) => c.status === "available");
  const totalRevenue = booked.reduce((sum, c) => sum + c.price, 0);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-20 px-6">
        <div className="container mx-auto max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-10"
          >
            <h1 className="font-display text-3xl font-bold tracking-[-0.04em] text-foreground flex items-center gap-3">
              <ShieldCheck className="h-8 w-8 text-primary" />
              Admin Dashboard
            </h1>
            <p className="text-muted-foreground mt-2">Fleet management & booking ledger</p>
          </motion.div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-10">
            {[
              { label: "Total Fleet", value: cars.length, icon: Car, color: "text-foreground" },
              { label: "Available", value: available.length, icon: TrendingUp, color: "text-accent" },
              { label: "Booked", value: booked.length, icon: ShieldCheck, color: "text-destructive" },
              { label: "Revenue/Day", value: `₹${totalRevenue.toLocaleString("en-IN")}`, icon: IndianRupee, color: "text-primary" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="card-veloce p-6"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">
                    {stat.label}
                  </span>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <div className={`text-3xl font-bold tabular-nums ${stat.color}`}>
                  {stat.value}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Bookings Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="card-veloce overflow-hidden"
          >
            <div className="p-6 border-b border-border">
              <h2 className="font-display text-lg font-bold tracking-[-0.02em] text-foreground">
                Booking Ledger
              </h2>
            </div>

            {booked.length === 0 ? (
              <div className="p-12 text-center">
                <Car className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No active bookings. Fleet is at full capacity.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">
                        Booking ID
                      </th>
                      <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">
                        Vehicle
                      </th>
                      <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">
                        Customer
                      </th>
                      <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">
                        Rate
                      </th>
                      <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">
                        Date
                      </th>
                      <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {booked.map((car, i) => (
                      <motion.tr
                        key={car.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.4 + i * 0.05 }}
                        className="border-b border-border hover:bg-secondary/30 transition-colors"
                      >
                        <td className="p-4 font-mono text-sm font-medium text-foreground">
                          #BK-{car.id.split("-")[1]}
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={car.image}
                              alt={car.name}
                              className="h-10 w-14 rounded-md object-cover"
                            />
                            <div>
                              <p className="text-sm font-medium text-foreground">{car.brand} {car.name}</p>
                              <p className="text-xs text-muted-foreground">{car.hp} HP · {car.fuel}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 text-sm text-foreground">{car.bookedBy}</td>
                        <td className="p-4 font-mono text-sm text-primary font-bold">
                          ₹{car.price.toLocaleString("en-IN")}
                        </td>
                        <td className="p-4 text-sm text-muted-foreground">{car.bookingDate}</td>
                        <td className="p-4">
                          <span className="badge-booked">BOOKED</span>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </motion.div>

          {/* All Cars Status */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="card-veloce overflow-hidden mt-6"
          >
            <div className="p-6 border-b border-border">
              <h2 className="font-display text-lg font-bold tracking-[-0.02em] text-foreground">
                Full Fleet Status
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">ID</th>
                    <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">Vehicle</th>
                    <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">Rate</th>
                    <th className="p-4 text-left text-xs font-bold tracking-[0.15em] text-muted-foreground uppercase">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {cars.map((car) => (
                    <tr key={car.id} className="border-b border-border hover:bg-secondary/30 transition-colors">
                      <td className="p-4 font-mono text-sm text-foreground">{car.id}</td>
                      <td className="p-4 text-sm font-medium text-foreground">{car.brand} {car.name}</td>
                      <td className="p-4 font-mono text-sm text-primary">₹{car.price.toLocaleString("en-IN")}/day</td>
                      <td className="p-4">
                        {car.status === "available" ? (
                          <span className="badge-available">AVAILABLE</span>
                        ) : (
                          <span className="badge-booked">BOOKED</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Admin;
